# simulacion
Repositorio destinado a los Trabajos Practicos de la Materia 75.26 - Simulación en Fiuba.

Notas:
- El informe se encuentra en formato pdf, por ello es necesario entrar al link del informe de la carátula que llevará al informe en Google Drive para ver correctamente los gifs animados.
- El link al repositorio se encuentra en la carátula, la cantidad de archivos entregados difiere de la cantidad de archivos que existen en el reposotorio debido a que en el repositorio se encuentran guardados los gifs e imagenes, algo que en los archivos de entrega se suprimieron por una cuestión de tamaño.
